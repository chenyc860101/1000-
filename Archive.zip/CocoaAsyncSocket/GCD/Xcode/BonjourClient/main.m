//
//  main.m
//  BonjourClient
//
//  Created by Robbie Hanson on 1/27/11.
//  Copyright 2011 Voalte. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
