//
//  QFAppDelegate.h
//  NSOperationExample
//
//  Created by Wu ming on 13-8-23.
//  Copyright (c) 2013年 千锋. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QFAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
