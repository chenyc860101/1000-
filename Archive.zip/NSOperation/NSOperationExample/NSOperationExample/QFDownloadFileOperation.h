//
//  QFDownloadFileOperation.h
//  NSOperationExample
//
//  Created by Wu ming on 13-8-27.
//  Copyright (c) 2013年 千锋. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum{
    document,
    libraryPreferences,
    libraryCaches,
    temp,
}sandbox;

@interface QFDownloadFileOperation : NSOperation


-(instancetype)initWithURL:(NSString *)url;

@property (nonatomic,strong) NSMutableURLRequest *urlRequest;
@property (nonatomic,strong) NSMutableData *contentData;
@property (nonatomic,strong) NSURLConnection *connection;
@property (nonatomic,assign) long long perdownloadLength;
@property (nonatomic,assign) long long totalLength;
@end
