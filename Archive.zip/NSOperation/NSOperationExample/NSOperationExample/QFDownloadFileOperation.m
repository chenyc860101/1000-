//
//  QFDownloadFileOperation.m
//  NSOperationExample
//
//  Created by Wu ming on 13-8-27.
//  Copyright (c) 2013年 千锋. All rights reserved.
//

#import "QFDownloadFileOperation.h"

@implementation QFDownloadFileOperation
@synthesize urlRequest;
@synthesize contentData;
@synthesize connection;
@synthesize perdownloadLength;
@synthesize totalLength;
#define DocumentsDirectory [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES) lastObject]
#define MUSICFile [DocumentsDirectory stringByAppendingPathComponent:@"filename.png"]

-(instancetype)initWithURL:(NSString *)url
{
    self = [self init];
    if (self) {
    
    //  unsigned long long downloadedBytes = [self fileSizeForPath:MUSICFile];
           unsigned long long downloadedBytes = 0;
        self.urlRequest= [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:url]];
        NSString *requestRange = [NSString stringWithFormat:@"bytes=%llu-", downloadedBytes];
        [self.urlRequest setValue:requestRange forHTTPHeaderField:@"Range"];
        [urlRequest setCachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData];
     //   [self.urlRequest setValue:@"" forHTTPHeaderField:@""];
        
        contentData = [[NSMutableData alloc]init];
        
    }
    return self;
}

-(void)start
{
    if (![self isCancelled]) {
        
        NSLog(@"requesitng %@",self.urlRequest);
        connection = [[NSURLConnection alloc]initWithRequest:self.urlRequest delegate:self];
        NSLog(@"url request %@",self.urlRequest.allHTTPHeaderFields);

        while (self.connection != nil) {
            [[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate distantFuture]];
        }
        
    }
}

-(BOOL)isFinished
{
    return self.connection == nil;
}

-(BOOL)isConcurrent
{
    return YES;
}
-(BOOL)isExecuting
{
    return self.connection == nil;
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
    NSLog(@"error with connection %@",[error description]);
    self.connection  = nil;
}

-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{

    NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)response;
    if (![httpResponse isKindOfClass:[NSHTTPURLResponse class]]) {
        return;
    }
    totalLength = httpResponse.expectedContentLength;
    

    
    NSLog(@"http response:%@",httpResponse.allHeaderFields);
    NSLog(@"total length:%lld",httpResponse.expectedContentLength);

}


- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    //  NSLog(@"data %@",data);
    [self.contentData appendData:data];
    perdownloadLength += [data length];
    NSLog(@"current downloaded %llu", perdownloadLength);
    NSLog(@"百分比: %.0f%%",((float)perdownloadLength/(float)totalLength) * 100);
}

- (void)connection:(NSURLConnection *)connection   didSendBodyData:(NSInteger)bytesWritten
 totalBytesWritten:(NSInteger)totalBytesWritten
totalBytesExpectedToWrite:(NSInteger)totalBytesExpectedToWrite
{
    NSLog(@"totalBytesWritten %ld",(long)totalBytesWritten);    
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    self.connection  = nil;
    //UIImage *imagecontent = [[UIImage alloc]initWithData:self.contentData];
   // [delegate updateUI:imagecontent rowIndex:tableIndex];
    
    NSString *path =  [self getPath:document];
    NSLog(@"path %@",path);
    NSString  *filePath = [NSString stringWithFormat:@"%@/%@", path,@"filename.png"];
    [self.contentData writeToFile:filePath atomically:YES];
}

-(NSString *)getPath:(sandbox)sandboxType
{
    NSArray *documentPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
    NSArray *libraryCache = NSSearchPathForDirectoriesInDomains(NSCachesDirectory,NSUserDomainMask,YES);
    NSString *tmpDir = NSTemporaryDirectory();
    NSString *path;
    switch (sandboxType) {
        case document:
            path = [documentPath objectAtIndex:0];
            break;
        case libraryCaches:
            path = [libraryCache objectAtIndex:0];
            case temp:
            path =tmpDir;
        default:
            break;
    }
    return path;
}

- (unsigned long long)fileSizeForPath:(NSString *)path {
    signed long long fileSize = 0;
    NSFileManager *fileManager = [NSFileManager new]; // not thread safe
    if ([fileManager fileExistsAtPath:path]) {
        NSError *error = nil;
        NSDictionary *fileDict = [fileManager attributesOfItemAtPath:path error:&error];
        if (!error && fileDict) {
            fileSize = [fileDict fileSize];
        }
    }
    return fileSize;
}


@end
