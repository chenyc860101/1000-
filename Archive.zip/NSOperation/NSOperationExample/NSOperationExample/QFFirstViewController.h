//
//  QFFirstViewController.h
//  NSOperationExample
//
//  Created by Wu ming on 8/24/13.
//  Copyright (c) 2013 千锋. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QFFirstViewController : UIViewController
@property (nonatomic,strong)UIProgressView *progressView;
@property (nonatomic,strong) UILabel *totalSize;
@property (nonatomic,strong) UILabel *currentSize;
@end
