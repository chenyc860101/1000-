//
//  QFFirstViewController.m
//  NSOperationExample
//
//  Created by Wu ming on 8/24/13.
//  Copyright (c) 2013 千锋. All rights reserved.
//

#import "QFFirstViewController.h"
#import "QFOperation.h"
#import "QFNetworkController.h"
#import "QFDownloadFileOperation.h"
#import "QFUploadFileOperation.h"
#import "QFNetworkOperation2.h"
#define downloadFile @"http://media.animusic2.com.s3.amazonaws.com/Animusic-ResonantChamber480p.mov"
#define IMAGEUrl @"http://image.sciencenet.cn/olddata/kexue.com.cn/upload/blog/images/2010/1/2010120123545554.jpg"

@interface QFFirstViewController ()
@property (nonatomic,strong) UIButton *button;
@end

@implementation QFFirstViewController
@synthesize button;
@synthesize progressView;
@synthesize totalSize;
@synthesize currentSize;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
       //[self.view addSubview:tableView];
    
    button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    button.tag  = 1;
    [button setTitle:@"NSInvocationOperation" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(invocationSelector:) forControlEvents:UIControlEventTouchUpInside];
    [button setFrame:CGRectMake(10, 10, 200,50)];
    [self.view addSubview:button];
    
    
    UIButton *button2 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    button2.tag  = 1;
    [button2 setTitle:@"NSBlockOperation" forState:UIControlStateNormal];
    [button2 addTarget:self action:@selector(blockSelector:) forControlEvents:UIControlEventTouchUpInside];
    [button2 setFrame:CGRectMake(10, 70, 200,50)];
    [self.view addSubview:button2];
    
    UIButton *button3 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    button3.tag  = 1;
    [button3 setTitle:@"NSOperation" forState:UIControlStateNormal];
    [button3 addTarget:self action:@selector(normalSelector:) forControlEvents:UIControlEventTouchUpInside];
    [button3 setFrame:CGRectMake(10, 130, 200,50)];
    [self.view addSubview:button3];
    
    UIButton *button4 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    button4.tag  = 1;
    [button4 setTitle:@"NSOperation network" forState:UIControlStateNormal];
    [button4 addTarget:self action:@selector(pushNetwork:) forControlEvents:UIControlEventTouchUpInside];
    [button4 setFrame:CGRectMake(10, 190, 200,50)];
    [self.view addSubview:button4];
    
    UIButton *button5 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [button5 setTitle:@"Download file" forState:UIControlStateNormal];
    [button5 addTarget:self action:@selector(downloadfile:) forControlEvents:UIControlEventTouchUpInside];
    [button5 setFrame:CGRectMake(10, 250, 200,50)];
    [self.view addSubview:button5];
    
    UIButton *button6 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [button6 setTitle:@"Upload file" forState:UIControlStateNormal];
    [button6 addTarget:self action:@selector(uploadFile:) forControlEvents:UIControlEventTouchUpInside];
    [button6 setFrame:CGRectMake(10, 310, 200,50)];
    [self.view addSubview:button6];
    
    UIButton *button7 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [button7 setTitle:@"断点续传" forState:UIControlStateNormal];
    [button7 addTarget:self action:@selector(downloadfile2:) forControlEvents:UIControlEventTouchUpInside];
    [button7 setFrame:CGRectMake(10, 360, 200,50)];
    [self.view addSubview:button7];
     progressView = [[UIProgressView alloc] initWithFrame:CGRectMake(10, 420, 250, 20)];
    
    [progressView setProgressViewStyle:UIProgressViewStyleDefault];
    
    [self.view addSubview:progressView];
    
    totalSize = [[UILabel alloc]initWithFrame:CGRectMake(10, 450, 200, 30)];
    [totalSize setBackgroundColor:[UIColor clearColor]];
    [self.view addSubview:totalSize];

    currentSize = [[UILabel alloc]initWithFrame:CGRectMake(100, 450, 200, 30)];
    [currentSize setBackgroundColor:[UIColor clearColor]];
    [self.view addSubview:currentSize];
    
}

-(void)downloadfile2:(id)sender
{
    QFNetworkOperation2 *operation2 = [[QFNetworkOperation2 alloc]initWithURL:nil];
    operation2.delegate = self;
    NSOperationQueue *queue = [[NSOperationQueue alloc]init];
    [queue addOperation:operation2];
    
    
    
}

-(void)updateUIWithCurrentSize:(long long)currentfileSize expectedDownloadSize:(long long)expectedDownloadSize
{
    
    float percentDone = (float)expectedDownloadSize/(float)currentfileSize;
    NSLog(@"expect size %f",percentDone);
     progressView.progress = percentDone;
    totalSize.text = [NSString stringWithFormat:@" %llu M",currentfileSize/1024/1024];
    currentSize.text = [NSString stringWithFormat:@" %llu M",expectedDownloadSize/1024/1024];

}
-(void)uploadFile:(id)sender
{
    QFUploadFileOperation *uploadfile = [[QFUploadFileOperation alloc]initWithImageName:@"test.jpg"];
        
    NSOperationQueue *queue = [[NSOperationQueue alloc]init];
    [queue addOperation:uploadfile];
    
}

-(void)downloadfile:(id)sender
{
    QFDownloadFileOperation *downloadOperation = [[QFDownloadFileOperation alloc]initWithURL:IMAGEUrl];
    NSOperationQueue *queue = [[NSOperationQueue alloc]init];
    [queue addOperation:downloadOperation];
}

-(void)pushNetwork:(id)sender
{    
    QFNetworkController  *qfNetwork = [[QFNetworkController alloc]init];
    [self.navigationController pushViewController:qfNetwork animated:YES];
}

-(void)normalSelector:(id)sender
{
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(updateUI:)//接收消息方法
                                                 name:@"updateUI"//消息识别名称
                                               object:nil];
    QFOperation *operation = [[QFOperation alloc]init];
    
    //[operation setQueuePriority:NSOperationQueuePriorityHigh];
    NSOperationQueue *queue = [[NSOperationQueue alloc]init];
    NSInvocationOperation *invoOperation = [[NSInvocationOperation alloc]initWithTarget:self selector:@selector(downloadImg:) object:nil];
    [invoOperation addDependency:operation];
    [queue addOperation:operation];
    [queue addOperation:invoOperation];
    //[queue setMaxConcurrentOperationCount:10];
    
}

-(void)updateUI:(id)sender
{
    NSLog(@"updaing ui");
}

-(void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"updateUI" object:nil];
    
}

-(void)blockSelector:(id)sender
{
    NSBlockOperation *blockOperation = [[NSBlockOperation alloc]init];
    NSLog(@"sart");
    [blockOperation addExecutionBlock:^{
        [NSThread sleepForTimeInterval:5];
        NSLog(@"finished");
    }];
    NSOperationQueue *queue = [[NSOperationQueue alloc]init];
    [queue addOperation:blockOperation];
}

-(void)invocationSelector:(id)sender
{
    NSInvocationOperation *invoOperation = [[NSInvocationOperation alloc]initWithTarget:self selector:@selector(downloadImg:) object:nil];
    NSOperationQueue *queue = [[NSOperationQueue alloc]init];
    [queue addOperation:invoOperation];
    NSLog(@"invo operation %d",invoOperation.isFinished);
    NSLog(@"invo operation %d",invoOperation.isConcurrent);
    NSLog(@"invo operation %d",invoOperation.isExecuting);
    NSLog(@"invo operation %d",invoOperation.isReady);
}

-(void)downloadImg:(UIButton *)sender
{
    
    dispatch_async(dispatch_get_main_queue(), ^{
        UIAlertView *alertview = [[UIAlertView alloc] initWithTitle:@"title" message:@"msg" delegate:self cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
           [alertview show];
    });
/*
    UIAlertView *alertview = [[UIAlertView alloc] initWithTitle:@"title" message:@"msg" delegate:self cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
    [alertview show];
     */
    //[alertview performSelectorOnMainThread:@selector(show) withObject:nil waitUntilDone:NO];
    //[button setTitle:@"Finished" forState:UIControlStateNormal];
  // [self performSelectorOnMainThread:@selector(updateUI:) withObject:nil waitUntilDone:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
