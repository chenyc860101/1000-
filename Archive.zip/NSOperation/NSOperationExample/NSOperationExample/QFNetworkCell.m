//
//  QFNetworkCell.m
//  NSOperationExample
//
//  Created by Wu ming on 8/25/13.
//  Copyright (c) 2013 千锋. All rights reserved.
//

#import "QFNetworkCell.h"

@implementation QFNetworkCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}



@end
