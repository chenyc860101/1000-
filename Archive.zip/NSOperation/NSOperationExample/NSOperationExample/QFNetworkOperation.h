//
//  QFNetworkOperation.h
//  NSOperationExample
//
//  Created by Wu ming on 8/25/13.
//  Copyright (c) 2013 千锋. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol updateUIProtocol
-(void)updateUI:(UIImage *)image rowIndex:(id)rowIndex;
@end


@interface QFNetworkOperation : NSOperation
@property (nonatomic,copy) NSString *imageUrl;
@property (nonatomic,strong) NSURLRequest *urlRequest;
@property (nonatomic,strong) NSMutableData *contentData;
@property (nonatomic,strong) NSURLConnection *connection;
@property (nonatomic,assign) BOOL isFinished;
@property (nonatomic,assign) BOOL isExecuting;
@property (nonatomic,strong) NSObject *tableIndex;
@property (nonatomic,weak) id delegate;
-(instancetype)initWithURL:(NSString *)url;

@end
