//
//  QFNetworkOperation.m
//  NSOperationExample
//
//  Created by Wu ming on 8/25/13.
//  Copyright (c) 2013 千锋. All rights reserved.
//

#import "QFNetworkOperation.h"

@interface QFNetworkOperation ()

@end

@implementation QFNetworkOperation
@synthesize imageUrl;
@synthesize urlRequest;
@synthesize contentData;
@synthesize connection;
@synthesize isFinished;
@synthesize isExecuting;
@synthesize delegate;
@synthesize tableIndex;

-(instancetype)initWithURL:(NSString *)url
{
    self = [self init];
    if (self) {
        self.imageUrl = url;
        urlRequest = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:url]];
            
        self.contentData = [[NSMutableData alloc]init];
    }
    return self;
}

-(void)start
{
    if (![self isCancelled]) {
        connection = [[NSURLConnection alloc]initWithRequest:self.urlRequest delegate:self];
        while (connection != nil) {
            [[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate distantFuture]];
        }
        
    }
}

-(BOOL)isConcurrent
{
    return YES;
}

-(BOOL)isFinished
{
    return connection == nil;
}

-(BOOL)isExecuting
{
    return connection ==nil;
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
    NSLog(@"error with connection %@",[error description]);
    self.connection  = nil;
}

-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    NSHTTPURLResponse * httpResponse = (NSHTTPURLResponse *)response;
    NSLog(@"http response %@",httpResponse.allHeaderFields);
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
        [self.contentData appendData:data];
}

- (void)connection:(NSURLConnection *)connection   didSendBodyData:(NSInteger)bytesWritten
 totalBytesWritten:(NSInteger)totalBytesWritten
totalBytesExpectedToWrite:(NSInteger)totalBytesExpectedToWrite
{
    NSLog(@"totalBytesWritten %ld",(long)totalBytesWritten);
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    self.connection  = nil;
    
    UIImage *imagecontent = [[UIImage alloc]initWithData:self.contentData];
    NSArray *documentPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);


    
    
    
    [delegate updateUI:imagecontent rowIndex:tableIndex];
}


@end
