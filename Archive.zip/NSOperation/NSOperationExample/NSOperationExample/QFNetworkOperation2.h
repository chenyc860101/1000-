//
//  QFNetworkOperation2.h
//  NSOperationExample
//
//  Created by Wu ming on 13-8-28.
//  Copyright (c) 2013年 千锋. All rights reserved.
//

#import <Foundation/Foundation.h>


@protocol updateUIDelegate

-(void)updateUIWithCurrentSize:(long long)currentfileSize expectedDownloadSize:(long long)expectedDownloadSize;

@end

@interface QFNetworkOperation2 : NSOperation

@property (nonatomic,strong) NSURLConnection *connection;
@property (nonatomic,strong) NSMutableURLRequest *request;
@property (nonatomic,strong) NSMutableData *contentData;
@property (nonatomic,assign) unsigned long long totalDownloadBytes;
@property (nonatomic,assign) long long totalLength;
@property (nonatomic,assign) long long perdownloadLength;

@property (nonatomic,unsafe_unretained) id delegate;
-(instancetype)initWithURL:(NSString *)url;




@end
