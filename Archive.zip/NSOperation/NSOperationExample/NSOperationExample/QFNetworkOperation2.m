//
//  QFNetworkOperation2.m
//  NSOperationExample
//
//  Created by Wu ming on 13-8-28.
//  Copyright (c) 2013年 千锋. All rights reserved.
//

#import "QFNetworkOperation2.h"

@implementation QFNetworkOperation2
@synthesize request,contentData,connection;
@synthesize totalDownloadBytes;
@synthesize delegate;
@synthesize totalLength;
@synthesize perdownloadLength;
#define DocumentsDirectory [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES) lastObject]
#define MUSICFile [DocumentsDirectory stringByAppendingPathComponent:@"test.mov"]

-(instancetype)initWithURL:(NSString *)url
{
    self = [self init];
    if (self) {
        self.request = [[NSMutableURLRequest alloc]initWithURL:[NSURL URLWithString:@"http://media.animusic2.com.s3.amazonaws.com/Animusic-ResonantChamber480p.mov"]];

        totalDownloadBytes = [self fileSizeForPath:MUSICFile];
        
       // NSMutableArray *hello = [[NSMutableArray alloc] init];
       // NSMutableArray *hello2 = hello;

        NSLog(@"total download byte %llu",totalDownloadBytes);
        
        if (totalDownloadBytes > 0) {
           
        }
        perdownloadLength = totalDownloadBytes;
        
        self.contentData = [[NSMutableData alloc]init];
        
        if (totalDownloadBytes > 0) {
            NSString *requestRange = [NSString stringWithFormat:@"bytes=%llu-", totalDownloadBytes];
            [self.request setValue:requestRange forHTTPHeaderField:@"Range"];
            [request setCachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData];
            [contentData appendData:[NSData dataWithContentsOfFile:MUSICFile]];
        }
        
    }
    
    return self;
}

-(void)start
{
    self.connection = [[NSURLConnection alloc]initWithRequest:self.request delegate:self];
    while (self.connection != nil) {
        [[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate distantFuture]];
    }
    
}

-(BOOL)isFinished
{
    return self.connection == nil;
}

-(BOOL)isConcurrent
{
    return YES;
}

-(BOOL)isExecuting
{
    return self.connection == nil;
}

-(void)connection:(NSURLConnection*)connection didReceiveData:(NSData *)data
{
    [self.contentData appendData:data];
    perdownloadLength += [data length];
    NSArray *documentPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
    NSString *path = [documentPath objectAtIndex:0];
    NSLog(@"path%@",path);
    NSString  *filePath = [NSString stringWithFormat:@"%@/%@", path,@"test.mov"];
    [self.contentData writeToFile:filePath atomically:YES];
    [delegate updateUIWithCurrentSize:totalLength expectedDownloadSize:perdownloadLength];
}

-(void)connection:(NSURLConnection*)connection didReceiveResponse:(NSURLResponse *)response
{
    NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)response;
    if (![httpResponse isKindOfClass:[NSHTTPURLResponse class]]) {
        return;
    }
    
    totalLength = httpResponse.expectedContentLength;
    NSLog(@"http response:%@",httpResponse.allHeaderFields);
    NSLog(@"total length:%lld",httpResponse.expectedContentLength);
  
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    self.connection = nil;
   }

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
    NSLog(@"error with connection %@",[error description]);
    self.connection  = nil;
}

- (unsigned long long)fileSizeForPath:(NSString *)path {
    signed long long fileSize = 0;
    NSFileManager *fileManager = [NSFileManager new]; // not thread safe
    if ([fileManager fileExistsAtPath:path]) {
    
        NSError *error = nil;
        NSDictionary *fileDict = [fileManager attributesOfItemAtPath:path error:&error];
        NSLog(@"file dict %@",fileDict);
        if (!error && fileDict) {
            fileSize = [fileDict fileSize];
            NSLog(@"fileSize %lld",fileSize);
        }
    }
    return fileSize;
}


@end
