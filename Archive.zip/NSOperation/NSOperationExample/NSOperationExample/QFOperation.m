//
//  QFOperation.m
//  NSOperationExample
//
//  Created by Wu ming on 8/25/13.
//  Copyright (c) 2013 千锋. All rights reserved.
//

#import "QFOperation.h"

@implementation QFOperation
@synthesize isExecuting,finished;

- (void)main { //  非并发操作
    // a lengthy operation
    @autoreleasepool {
        for (int i = 0 ; i < 10000 ; i++) {
            NSLog(@"%f", sqrt(i));
        }
    }
}

-(void)start
{
    finished = NO;
    isExecuting = YES;
    NSLog(@"start");
    [self operating];
}


-(BOOL)isConcurrent {
    return YES;
}

-(BOOL)isExecuting
{
    return YES;
}

-(BOOL)isFinished
{
    return finished;
}

-(void)operating
{
    [NSThread sleepForTimeInterval:5];
    NSLog(@"operating finished");
    finished = YES;
    isExecuting = NO;
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"updateUI" object:nil];
    
    
}



@end
