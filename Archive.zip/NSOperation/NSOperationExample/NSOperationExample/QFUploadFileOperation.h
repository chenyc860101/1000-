//
//  QFUploadFileOperation.h
//  NSOperationExample
//
//  Created by Wu ming on 13-8-27.
//  Copyright (c) 2013年 千锋. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface QFUploadFileOperation : NSOperation

@property (nonatomic,strong) NSMutableURLRequest *urlRequest;
@property (nonatomic,strong) NSURLConnection *connection;
@property (nonatomic,strong) NSMutableData *contentData;


-(instancetype)initWithImageName:(NSString *)imageName;

@end
