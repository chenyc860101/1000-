//
//  QFUploadFileOperation.m
//  NSOperationExample
//
//  Created by Wu ming on 13-8-27.
//  Copyright (c) 2013年 千锋. All rights reserved.
//

#import "QFUploadFileOperation.h"

@implementation QFUploadFileOperation
@synthesize contentData,urlRequest,connection;

-(instancetype)initWithImageName:(NSString *)imageName
{
    self = [self init];
    if (self) {
        if (![self isCancelled]) {
            self.urlRequest = [[NSMutableURLRequest alloc]initWithURL:[NSURL URLWithString:@"http://localhost/upload/upload_file.php"]];
            NSData* fileData = UIImageJPEGRepresentation([UIImage imageNamed:@"test.jpg"], 0.8);
            NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
            [request setURL:[NSURL URLWithString:@"http://localhost/upload/upload_file.php"]];
            [request setHTTPMethod:@"POST"];
            NSString *boundary = [NSString stringWithFormat:@"0xKhTmLbOuNdArY"]; // This is important! //NSURLConnection is very sensitive to format.
            NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@",boundary];
            [request addValue:contentType forHTTPHeaderField: @"Content-Type"];
            NSMutableData *body = [NSMutableData data];
            [body appendData:[[NSString stringWithFormat:@"--%@\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
            
            [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"file\"; filename=\"thefilename.jpg\"\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
            [body appendData:[[NSString stringWithFormat:@"Content-Type: application/octet-stream\r\n\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
            [body appendData:[NSData dataWithData:fileData]];
            [body appendData:[[NSString stringWithFormat:@"r\n--%@--\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
            // setting the body of the post to the reqeust
          
            [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"param3\"\r\n\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
            [body appendData:[[NSString stringWithFormat:@"paramstringvalue2"] dataUsingEncoding:NSUTF8StringEncoding]];
            [body appendData:[[NSString stringWithFormat:@"r\n--%@--\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
            
            [request setHTTPBody:body];
            
            // now lets make the connection to the web
            NSData *returnData = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
            
            
            NSLog(@"%@",[[NSString alloc] initWithData:returnData encoding:NSUTF8StringEncoding]);
            
            while (self.connection != nil) {
                [[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate distantFuture]];
            }
            
        }
        
        
    }
    return self;
}

-(void)start
{

    if (![self isCancelled]) {
        
        NSLog(@"requesitng %@",self.urlRequest);
        connection = [[NSURLConnection alloc]initWithRequest:self.urlRequest delegate:self];
    
        
        NSLog(@"url request %@",self.urlRequest.allHTTPHeaderFields);
        
        while (self.connection != nil) {
            [[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate distantFuture]];
        }
        
    }
    
}

-(BOOL)isConcurrent
{
    return YES;
}

-(BOOL)isFinished
{
    return connection == nil;

}

-(BOOL)isExecuting
{
    return connection == nil;
}

-(void)connection:(NSURLConnection*)connection didReceiveData:(NSData *)data
{
    NSLog(@"hello");
}

-(void)connection:(NSURLConnection*)connection didReceiveResponse:(NSURLResponse *)response
{
    NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)response;
    if (![httpResponse isKindOfClass:[NSHTTPURLResponse class]]) {
        return;
    }
    
    NSLog(@"http response:%@",httpResponse.allHeaderFields);
    NSLog(@"total length:%lld",httpResponse.expectedContentLength);
    
    
    
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    self.connection = nil;
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
    NSLog(@"error with connection %@",[error description]);
    self.connection  = nil;
}


@end
