//
//  QFNetworkController.m
//  NSOperationExample
//
//  Created by Wu ming on 8/25/13.
//  Copyright (c) 2013 千锋. All rights reserved.
//

#import "QFNetworkController.h"
#import "QFNetworkOperation.h"
#import "QFNetworkCell.h"
#define IS_IPHONE   ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
#define IS_IPHONE_5 ([[UIScreen mainScreen] bounds ].size.height == HEIGHT_IPHONE_5 )


@interface QFNetworkController ()

@end

@implementation QFNetworkController
@synthesize tableview;
@synthesize siteArray;
@synthesize queue;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
     queue = [[NSOperationQueue alloc]init];

    self.siteArray = [[NSMutableArray alloc] init];
    [self.siteArray addObject:@"http://s1.lashouimg.com/zt/201110/27/131972321636938600.jpg"];
    [self.siteArray addObject:@"http://s1.lashouimg.com/zt/201110/25/131953930325377400.jpg"];
    [self.siteArray addObject:@"http://s1.lashouimg.com/zt/201110/25/131953847613105000.jpg"];
    [self.siteArray addObject:@"http://s1.lashouimg.com/zt/201110/27/131972570125915500.jpg"];
    [self.siteArray addObject:@"http://s1.lashouimg.com/zt/201110/25/131954190510086200.jpg"];
    [self.siteArray addObject:@"http://s1.lashouimg.com/zt/201110/27/131972321636938600.jpg"];
    [self.siteArray addObject:@"http://s1.lashouimg.com/zt/201110/25/131953930325377400.jpg"];
    [self.siteArray addObject:@"http://s1.lashouimg.com/zt/201110/25/131953847613105000.jpg"];
    [self.siteArray addObject:@"http://s1.lashouimg.com/zt/201110/27/131972570125915500.jpg"];
    [self.siteArray addObject:@"http://s1.lashouimg.com/zt/201110/25/131954190510086200.jpg"];
    [self.siteArray addObject:@"http://s1.lashouimg.com/zt/201110/27/131972321636938600.jpg"];
    [self.siteArray addObject:@"http://s1.lashouimg.com/zt/201110/25/131953930325377400.jpg"];
    [self.siteArray addObject:@"http://s1.lashouimg.com/zt/201110/25/131953847613105000.jpg"];
    [self.siteArray addObject:@"http://s1.lashouimg.com/zt/201110/27/131972570125915500.jpg"];
    [self.siteArray addObject:@"http://s1.lashouimg.com/zt/201110/25/131954190510086200.jpg"];
    [self.siteArray addObject:@"http://s1.lashouimg.com/zt/201110/27/131972321636938600.jpg"];
    [self.siteArray addObject:@"http://s1.lashouimg.com/zt/201110/25/131953930325377400.jpg"];
    [self.siteArray addObject:@"http://s1.lashouimg.com/zt/201110/25/131953847613105000.jpg"];
    [self.siteArray addObject:@"http://s1.lashouimg.com/zt/201110/27/131972570125915500.jpg"];
    [self.siteArray addObject:@"http://s1.lashouimg.com/zt/201110/25/131954190510086200.jpg"];
    [self.siteArray addObject:@"http://s1.lashouimg.com/zt/201110/27/131972321636938600.jpg"];
    [self.siteArray addObject:@"http://s1.lashouimg.com/zt/201110/25/131953930325377400.jpg"];
    [self.siteArray addObject:@"http://s1.lashouimg.com/zt/201110/25/131953847613105000.jpg"];
    [self.siteArray addObject:@"http://s1.lashouimg.com/zt/201110/27/131972570125915500.jpg"];
    [self.siteArray addObject:@"http://s1.lashouimg.com/zt/201110/25/131954190510086200.jpg"];
    [self.siteArray addObject:@"http://s1.lashouimg.com/zt/201110/27/131972321636938600.jpg"];
    [self.siteArray addObject:@"http://s1.lashouimg.com/zt/201110/25/131953930325377400.jpg"];
    [self.siteArray addObject:@"http://s1.lashouimg.com/zt/201110/25/131953847613105000.jpg"];
    [self.siteArray addObject:@"http://s1.lashouimg.com/zt/201110/27/131972570125915500.jpg"];
    [self.siteArray addObject:@"http://s1.lashouimg.com/zt/201110/25/131954190510086200.jpg"];

    self.tableview = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height - 88) style:UITableViewStylePlain];
        
    self.tableview.delegate = self;
    self.tableview.dataSource = self;
    [self.view addSubview:self.tableview];

}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 10;
}

- (UITableViewCell *)tableView:(UITableView *)tableView1 cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * showUserInfoCellIdentifier = @"ShowUserInfoCell";
    QFNetworkCell * cell = [tableView1 dequeueReusableCellWithIdentifier:showUserInfoCellIdentifier];
    if (cell == nil)
    {
        // Create a cell to display an ingredient.
        cell = [[QFNetworkCell alloc] initWithStyle:UITableViewCellStyleDefault
                                      reuseIdentifier:showUserInfoCellIdentifier];
        QFNetworkOperation *networkOperation = [[QFNetworkOperation alloc]initWithURL:[self.siteArray objectAtIndex:indexPath.row]];
                
        networkOperation.delegate = self;
        networkOperation.tableIndex = indexPath;
        [self.queue addOperation:networkOperation];
          
     //  cell.contentView set
    }
    
   
    
    return cell;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 112;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)updateUI:(UIImage *)image rowIndex:(id)rowIndex
{
    NSIndexPath *indexPath = (NSIndexPath *)rowIndex;
    QFNetworkCell *cell = (QFNetworkCell *)[self.tableview cellForRowAtIndexPath:indexPath];
    cell.imageView.image = image;
    //[cell setNeedsDisplay];
}

-(void)viewWillDisappear:(BOOL)animated
{
    [queue cancelAllOperations];
}

-(void)dealloc
{
    [queue cancelAllOperations];
}
@end
