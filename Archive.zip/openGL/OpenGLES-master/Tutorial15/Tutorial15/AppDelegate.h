//
//  AppDelegate.h
//  Tutorial15
//
//  Created by kesalin@gmail.com kesalin on 13-1-2.
//  Copyright (c) 2013年 http://blog.csdn.net/kesalin/. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
