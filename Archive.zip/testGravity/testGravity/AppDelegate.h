//
//  AppDelegate.h
//  testGravityLocation
//
//  Created by shawn li on 13-7-30.
//  Copyright (c) 2013年 bigbellshawn. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
