//
//  GravityBallView.h
//  testGravityLocation
//
//  Created by shawn li on 13-7-30.
//  Copyright (c) 2013年 bigbellshawn. All rights reserved.
//  http://bigbelldev.com
//

#import <UIKit/UIKit.h>
#import <CoreMotion/CoreMotion.h>
/* 协议给delegation使用，能够告诉label，现在x和y方向上实时更新的加速度 */
@protocol GravityBallViewDelegate
- (void)updateLabelWithX:(double)accelerometerX Y:(double)accelerometerY;
@end


@interface GravityBallView : UIView 
@property (nonatomic, strong) CMMotionManager *mManager;
@property (nonatomic, weak) id<GravityBallViewDelegate> delegate;

- (void)startUpdateAccelerometer;
- (void)stopUpdate;
@end
