//
//  GravityBallView.m
//  testGravityLocation
//
//  Created by shawn li on 13-7-30.
//  Copyright (c) 2013年 bigbellshawn. All rights reserved.
//  http://bigbelldev.com
//

#import "GravityBallView.h"

@interface GravityBallView()
@property (readwrite) float velocity;
@end


@implementation GravityBallView
@synthesize velocity;
@synthesize mManager = _mManager;
@synthesize delegate;

/* designate initializer */
- (id)initWithFrame:(CGRect)frame
{

    self = [super initWithFrame:frame];
    if (self) {
        _mManager = [[CMMotionManager alloc] init];
        /* 小球运动的速度（加速度的倍数），越大球运动越快，感觉上越灵敏 */
        self.velocity = 400;
    }
    return self;
}
/* lazy init */
- (CMMotionManager *)mManager
{
    if (!_mManager) {
        _mManager = [[CMMotionManager alloc] init];
    }
    return _mManager;
}

- (void)startUpdateAccelerometer
{
    /* 设置采样的频率，单位是秒 */
    NSTimeInterval updateInterval = 0.07;
    
    CGSize size = [self superview].frame.size;
	__block CGRect f = [self frame];
    
    //在block中，只能使用weakSelf。
    GravityBallView * __weak weakSelf = self;
    
    /* 判断是否加速度传感器可用，如果可用则继续 */
    if ([self.mManager isAccelerometerAvailable] == YES) {
        /* 给采样频率赋值，单位是秒 */
        [self.mManager setAccelerometerUpdateInterval:updateInterval];

        /* 加速度传感器开始采样，每次采样结果在block中处理 */
        [self.mManager startAccelerometerUpdatesToQueue:[NSOperationQueue currentQueue] withHandler:^(CMAccelerometerData *accelerometerData, NSError *error)
        {
            f.origin.x += (accelerometerData.acceleration.x * weakSelf.velocity) * 1;
            f.origin.y += (accelerometerData.acceleration.y * weakSelf.velocity) * -1;

            if(f.origin.x < 0)
                f.origin.x = 0;
            if(f.origin.y < 0)
                f.origin.y = 0;
            
            if(f.origin.x > (size.width - f.size.width))
                f.origin.x = (size.width - f.size.width);
            if(f.origin.y > (size.height - f.size.height))
                f.origin.y = (size.height - f.size.height);
            
            /* 运动动画 */
            [UIView beginAnimations:nil context:nil];
            [UIView setAnimationDuration:0.1];
            [weakSelf setFrame:f];
            [UIView commitAnimations];
            
            [weakSelf.delegate updateLabelWithX:accelerometerData.acceleration.x Y:accelerometerData.acceleration.y];
        }];
    }

}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

/* 停止传感器，当不是用的时候要及时停掉 */
- (void)stopUpdate
{
    if ([self.mManager isAccelerometerActive] == YES)
    {
        [self.mManager stopAccelerometerUpdates];
    }

}


@end
