//
//  ViewController.h
//  testGravityLocation
//
//  Created by shawn li on 13-7-30.
//  Copyright (c) 2013年 bigbellshawn. All rights reserved.
//  http://bigbelldev.com
//

#import <UIKit/UIKit.h>
#import "GravityBallView.h"


@interface ViewController : UIViewController <GravityBallViewDelegate>
@property (nonatomic, strong) GravityBallView *gravityBallView;
@property (nonatomic, strong) UIImageView *imageView;
@end
