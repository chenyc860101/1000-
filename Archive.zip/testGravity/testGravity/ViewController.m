//
//  ViewController.m
//  testGravityLocation
//
//  Created by shawn li on 13-7-30.
//  Copyright (c) 2013年 bigbellshawn. All rights reserved.
//  http://bigbelldev.com
//

#import "ViewController.h"

@interface ViewController ()
@property (nonatomic, strong) UIButton *button;
@property (nonatomic, strong) UIView *bounderView;
@property (nonatomic, strong) UILabel *label;
@end

@implementation ViewController
@synthesize gravityBallView = _gravityBallView;
@synthesize imageView = _imageView;
@synthesize button = _button;
@synthesize bounderView = _bounderView;
@synthesize label = _label;
- (void)viewDidLoad
{
    [super viewDidLoad];
    _bounderView = [[UIView alloc] init];
    [_bounderView setFrame:CGRectMake(5, 5, 320 - 10, 400 - 10)];//是不是self自带的这个view是不能改大小的？原来的写法是直接self.view setFrame不管用。
    [_bounderView setBackgroundColor:[UIColor colorWithRed:0.2 green:0.8 blue:0.2 alpha:0.7]];
    [self.view addSubview:_bounderView];
    
    CGRect gravityBallViewFrame = CGRectMake(0, 0, 40, 40);
    _gravityBallView = [[GravityBallView alloc] initWithFrame:gravityBallViewFrame];
    [_bounderView addSubview:_gravityBallView];
    _gravityBallView.delegate = self;
    
    _imageView = [[UIImageView alloc] initWithFrame:gravityBallViewFrame];
    _imageView.image = [UIImage imageNamed:@"billiard.png"];
    [_gravityBallView addSubview:_imageView];
    
    [_gravityBallView startUpdateAccelerometer];
    
    _label = [[UILabel alloc] initWithFrame:CGRectMake(10, 400, 200, 50)];
    _label.backgroundColor = [UIColor colorWithRed:0.2 green:0.2 blue:0.8 alpha:0.6];
    [self.view addSubview:_label];
    
    
    _button = [[UIButton alloc] initWithFrame:CGRectMake(220, 405, 90, 40)];
    _button.backgroundColor = [UIColor colorWithRed:0.8 green:0.2 blue:0.2 alpha:0.6];
    [_button setTitle:@"stop" forState:UIControlStateNormal];
    [_button addTarget:self action:@selector(onButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_button];

}
- (void)onButtonClicked:(UIButton*)button{
    if ([_gravityBallView.mManager isAccelerometerActive] == YES)
    {
        [_gravityBallView stopUpdate];
        [_button setTitle:@"start" forState:UIControlStateNormal];
    } else if(([_gravityBallView.mManager isAccelerometerActive] != YES) &&
              ([_gravityBallView.mManager isAccelerometerAvailable] == YES))
    {
        [_gravityBallView startUpdateAccelerometer];
        [_button setTitle:@"stop" forState:UIControlStateNormal];
    }
    else
    {
        NSLog(@"what's happenning?\n");
    }

}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillDisappear:(BOOL)animated
{
    [_gravityBallView stopUpdate];
}

#pragma GravityBallViewDelegate
- (void)updateLabelWithX:(double)accelerometerX Y:(double)accelerometerY
{
    self.label.text = [NSString stringWithFormat:@"X:%f-Y:%f", accelerometerX, accelerometerY];
}
@end
