//
//  RootViewController.h
//  HelloWorld
//
//  Created by Yang QianFeng on 12-1-4.
//  Copyright (c) 2012年 千锋3G www.mobiletrain.org. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UIViewController
{
    NSURLConnection *requestConnection;
    NSMutableData *allData;
}

@end
