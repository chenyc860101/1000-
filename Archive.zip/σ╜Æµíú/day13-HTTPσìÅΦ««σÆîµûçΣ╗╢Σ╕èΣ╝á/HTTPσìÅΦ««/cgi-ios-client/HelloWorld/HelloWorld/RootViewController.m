//
//  RootViewController.m
//  HelloWorld
//
//  Created by Yang QianFeng on 12-1-4.
//  Copyright (c) 2012年 千锋3G www.mobiletrain.org. All rights reserved.
//

#import "RootViewController.h"

@implementation RootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle
- (void) testGet
{
    NSString *urlString = @"http://localhost/cgi-bin/ios1.cgi?myUserName1=1233&myPassWord1=111&myMessage1=323";
    NSURL *url = [NSURL URLWithString:urlString];
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL:url];
    requestConnection = [[NSURLConnection alloc] initWithRequest:request delegate:self];
    [request release];
}

- (void) testPostUrl
{
    NSString *body = @"SrcLatitude=40.029997&SrcLongitude=116.346653&DestLatitude=40.032112&DestLongitude=116.35555";
    
    NSString *urlString = @"http://localhost/cgi-bin/ios1.cgi";
    NSURL *url = [NSURL URLWithString:urlString];
    
    NSMutableURLRequest* req;
    req = [NSMutableURLRequest requestWithURL:url];
    [req setHTTPMethod:@"POST"];
    // 设置请求方法为POST 缺省是 GET
    //[req setHTTPShouldHandleCookies:NO];
    [req setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    // 设置请求头字段 给请求头设置一个字段Content-Type 
    // Content-Type: application/x-www-form-urlencoded
    
    int contentLength = [body lengthOfBytesUsingEncoding:NSUTF8StringEncoding];
    // 求字符串body所占的字节数
    int a = [body length]; 
    //求body字符个数  body=@"我爱中国共产党dang" a = 7
    
    [req setValue:[NSString stringWithFormat:@"%d", contentLength] forHTTPHeaderField:@"Content-Length"];
    // 给请求头 加入一项 
    // Content-Length: 512
    [req setHTTPBody:[body dataUsingEncoding:NSUTF8StringEncoding]];
    // [body dataUsingEncoding:NSUTF8StringEncoding]
    // 把body转成NSData (字符串转成二进制nsdata)
    // setHTTPBody就是给请求req设置请求体
    
    requestConnection = [[NSURLConnection alloc] initWithRequest:req delegate:self];
    // 把请求req发送到网络上 发到apache2中去
}

#define TEST_FORM_BOUNDARY @"123QianFeng12345678"
- (void) testPostFormData:(NSData*)data
{
    NSString *urlString = @"http://localhost/cgi-bin/ios1.cgi";
    NSURL *url = [NSURL URLWithString:urlString];
    
	NSMutableURLRequest* req;
    req = [NSMutableURLRequest requestWithURL:url
            cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData
            timeoutInterval:20.0f];
	NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@", TEST_FORM_BOUNDARY];
    [req setHTTPShouldHandleCookies:NO];
    [req setHTTPMethod:@"POST"];
    [req setValue:contentType forHTTPHeaderField:@"Content-Type"];
    [req setValue:[NSString stringWithFormat:@"%d", [data length]] forHTTPHeaderField:@"Content-Length"];
    [req setHTTPBody:data];
    requestConnection = [[NSURLConnection alloc] initWithRequest:req delegate:self];
}

- (void) testPostPicData:(NSData*)data
{
    NSString *urlString = @"http://localhost/cgi-bin/ios3.cgi";
    NSURL *url = [NSURL URLWithString:urlString];
    
	NSMutableURLRequest* req;
    req = [NSMutableURLRequest requestWithURL:url
                                  cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData
                              timeoutInterval:20.0f];
	NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@", TEST_FORM_BOUNDARY];
    [req setHTTPShouldHandleCookies:NO];
    [req setHTTPMethod:@"POST"];
    [req setValue:contentType forHTTPHeaderField:@"Content-Type"];
    [req setValue:[NSString stringWithFormat:@"%d", [data length]] forHTTPHeaderField:@"Content-Length"];
    [req setHTTPBody:data];
    requestConnection = [[NSURLConnection alloc] initWithRequest:req delegate:self];
}

- (NSString*) nameValString: (NSDictionary*) dict {
	NSArray* keys = [dict allKeys];
	NSString* result = [NSString string];
	int i;
	for (i = 0; i < [keys count]; i++) {
        result = [result stringByAppendingString:
                  [@"--" stringByAppendingString:
                   [TEST_FORM_BOUNDARY stringByAppendingString:
                    [@"\r\nContent-Disposition: form-data; name=\"" stringByAppendingString:
                     [[keys objectAtIndex: i] stringByAppendingString:
                      [@"\"\r\n\r\n" stringByAppendingString:
                       [[dict valueForKey: [keys objectAtIndex: i]] stringByAppendingString: @"\r\n"]]]]]]];
	}
	
	return result;
}

- (void) testPostFormData
{
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
						 @"1234", @"myUserName1",
						 @"3456", @"myPassWord1",
                         nil];

    NSString *param = [self nameValString:dic];
    NSString *footer = [NSString stringWithFormat:@"\r\n--%@--\r\n", TEST_FORM_BOUNDARY];
    
    param = [param stringByAppendingString:[NSString stringWithFormat:@"--%@\r\n", TEST_FORM_BOUNDARY]];
    
    param = [param stringByAppendingString:@"Content-Disposition: form-data; name=\"myMessage1\"\r\n\r\n"];
    NSString *myMessage1 = @"23223";

    NSMutableData *data = [NSMutableData data];
    [data appendData:[param dataUsingEncoding:NSUTF8StringEncoding]];
    [data appendData:[myMessage1 dataUsingEncoding:NSUTF8StringEncoding]]; 
    [data appendData:[footer dataUsingEncoding:NSUTF8StringEncoding]];
    NSLog(@"param:%@", param);
    
    [self testPostFormData:data];
}

- (void) testPicUpload
{
    NSString *picPath = [[NSBundle mainBundle] pathForResource:@"testicon" ofType:@"png"];
    NSData *png = [NSData dataWithContentsOfFile:picPath];
//    UIImage *image = [UIImage imageNamed:@"testicon.png"];
//    NSData *jpeg = UIImagePNGRepresentation(image);
    
    NSString *param = @"";
    NSString *footer = [NSString stringWithFormat:@"\r\n--%@--\r\n", TEST_FORM_BOUNDARY];

    param = [param stringByAppendingString:[NSString stringWithFormat:@"--%@\r\n", TEST_FORM_BOUNDARY]];
    param = [param stringByAppendingString:@"Content-Disposition: form-data; name=\"filename\";filename=\"testicon.png\"\r\nContent-Type: image/png\r\n\r\n"];
	
    NSMutableData *data = [NSMutableData data];
    [data appendData:[param dataUsingEncoding:NSUTF8StringEncoding]];
    [data appendData:png];
    [data appendData:[footer dataUsingEncoding:NSUTF8StringEncoding]];
    NSLog(@"param:%@", param);
    [self testPostPicData:data];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    //[self testGet];
    [self testPostUrl];
    //[self testPostFormData];
    //[self testPicUpload];
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    [requestConnection release];
    /* 把allData转化成NSString对象 */
    NSString *string = [[NSString alloc] initWithData:allData encoding:NSUTF8StringEncoding];
    
    NSLog(@"string is %@", string);
    /* 2 JSON解析 */
    /* 1. */
    [allData release];
    [string release];
}
/* 函数2 接收完HTTP协议头的函数 真正数据开始接受时候调用 */
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    allData = [[NSMutableData alloc] initWithLength:0];
    NSLog(@"function %s is calling", __func__);
    
    NSHTTPURLResponse *res = (NSHTTPURLResponse *)response;
    NSInteger statusCode = [res statusCode];
    if (statusCode >= 400 ) {
        NSLog(@"HTTP ERORR CODE %d", statusCode);
    }
    NSDictionary *dic = [res allHeaderFields];
    NSLog(@"all Header Fields");
    NSLog(@"%@", dic);
    int len = [[dic objectForKey:@"Content-Length"] intValue];
    NSLog(@"server data len is %d", len);
}
/* 函数3 每接受一小段数据就会调用 */
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    NSLog(@"functiono %s is calling", __func__);
    [allData appendData:data];
    /* 把data追加到 allData最后 */
}

@end
